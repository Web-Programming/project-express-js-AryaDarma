exports.getHome = (req, res) => {
  res.render("index", {title: "Selamat Datang di Toko Online"});
};
