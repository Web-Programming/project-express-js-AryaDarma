const products = [
  {id: 1, name: "Laptop Gaming"},
  {id: 2, name: "Mouse Wireless"},
  {id: 3, name: "Keyboard Mechanical"},
];

module.exports = products;
